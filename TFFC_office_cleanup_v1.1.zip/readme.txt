1. Extract zip to -> C:\Temp\

2. WIN + R, then type -> powershell

3. Run this command -> Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

4. Run this command -> C:\Temp\TFFC_office_cleanup\run.ps1
