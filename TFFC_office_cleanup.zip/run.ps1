#V1.3

Add-Type -AssemblyName Microsoft.VisualBasic

function Remove-ToRecycleBin {
    param(
        [Parameter(Mandatory,ValueFromPipeline,ValueFromPipelineByPropertyName)]
        [string[]]$Path
    )

    process {
        foreach ($p in $Path) {
            if (Test-Path $p -PathType Leaf) {
                [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile(
                    $p, 'OnlyErrorDialogs', 'SendToRecycleBin'
                )
            } elseif (Test-Path $p -PathType Container) {
                [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory(
                    $p, 'OnlyErrorDialogs', 'SendToRecycleBin'
                )
            }
        }
    }
}

# Helper: run a scriptblock elevated (UAC prompt), then return
function Invoke-Elevated {
    param(
        [Parameter(Mandatory)]
        [ScriptBlock]$ScriptBlock
    )

    # Encode the scriptblock to pass to powershell.exe
    $bytes   = [Text.Encoding]::Unicode.GetBytes($ScriptBlock.ToString())
    $encoded = [Convert]::ToBase64String($bytes)

    Start-Process powershell.exe -Verb RunAs -ArgumentList "-NoProfile -EncodedCommand $encoded" -Wait
}

Write-Host ""
Write-Host "[TFFC Office/Microsoft Cleanup Script]" -ForegroundColor Cyan
Write-Host ""
Write-Host "Are you sure you want to run this script? (Y/N):" -ForegroundColor Yellow -nonewline
$answer = Read-Host

if ($answer -notin @('Y','y','Yes','yes')) {
    Write-Host "Aborting..." -ForegroundColor Yellow
    Write-Host ""
    exit
}

$procs = @('winword','excel','powerpnt','outlook','onenote','msaccess','lync','teams','ms-teams','olk')

foreach ($p in $procs) {
    Write-Host "Stopping $p..." -ForegroundColor Green
    Get-Process -Name $p -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
}

# Teams cache
Write-Host "Deleting Teams cache..." -ForegroundColor Green
$teamsNew = Join-Path $env:LOCALAPPDATA 'Packages\MSTeams_8wekyb3d8bbwe\*'
Remove-Item $teamsNew -Recurse -Force -ErrorAction SilentlyContinue

# Outlook cache
Write-Host "Deleting Outlook cache..." -ForegroundColor Green
$outlookRoamCache = Join-Path $env:LOCALAPPDATA 'Microsoft\Outlook\RoamCache\*'
Remove-Item $outlookRoamCache -Recurse -Force -ErrorAction SilentlyContinue

$newOutlookProfile = Join-Path $env:LOCALAPPDATA 'Microsoft\Olk\*'
Remove-Item $newOutlookProfile -Recurse -Force -ErrorAction SilentlyContinue

Get-AppxPackage Microsoft.OutlookForWindows -ErrorAction SilentlyContinue | Reset-AppxPackage

# Opening Access work or school
Write-Host ""
Write-Host "Opening: Settings -> Accounts -> Access work or school..." -ForegroundColor Magenta
Write-Host "Please disconnect the account..." -ForegroundColor   
Start-sleep -seconds 3
Start-Process "ms-settings:workplace"
Write-Host "When done, press <Enter> for next step..." -ForegroundColor Yellow -nonewline
Read-Host

# Opening Control panel for Mail Profile
Write-Host ""
Write-Host "Opening: Control panel..." -ForegroundColor Magenta
Write-Host "Please open <Mail> and remove the profile..." -ForegroundColor Magenta
Start-sleep -seconds 3
Start-Process "control"
Write-Host "When done, press <Enter> for next step..." -ForegroundColor Yellow -nonewline
Read-Host

# Delete OST/NST
Write-Host "Deleting OST/NST... (moving to recycle bin)" -ForegroundColor Green
$outlookDataRoot = Join-Path $env:LOCALAPPDATA 'Microsoft\Outlook'
Get-ChildItem $outlookDataRoot -Include *.ost,*.nst -File -Recurse -ErrorAction SilentlyContinue | Remove-ToRecycleBin -ErrorAction SilentlyContinue

# Create an Outlook profile for the CURRENT USER via Autodiscover (ZeroConfigExchange)
try{
    Write-Host "Creating an Outlook profile (ZeroConfigExchange)..." -ForegroundColor Green
    $ProfileName = "TFFC" 
    $baseKey = "HKCU:\Software\Microsoft\Office\16.0\Outlook"
    New-Item -Path $baseKey -Force | Out-Null
    Set-ItemProperty -Path $baseKey -Name DefaultProfile -Value $ProfileName
    $autoDiscoverKey = Join-Path $baseKey "AutoDiscover"
    New-Item -Path $autoDiscoverKey -Force | Out-Null
    New-ItemProperty -Path $autoDiscoverKey -Name ZeroConfigExchange -Value 1 -PropertyType DWord -Force | Out-Null
}catch{
    Write-Host "Couldn't create an Outlook profile..." -ForegroundColor Red
}

# OneDrive
Write-Host ""
Write-Host "Please open <OneDrive> from the tray bar, then Settings -> Account -> Unlink this PC..." -ForegroundColor Magenta
Write-Host "When done, press <Enter> for next step..." -ForegroundColor Yellow -nonewline
Read-Host

# Close OneDrive
$procs = @('OneDrive','OneDriveStandaloneUpdater')
foreach ($p in $procs) {
    Write-Host "Stopping $p..." -ForegroundColor Green
    Get-Process -Name $p -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
}

# Deleting OneDrive cache
Write-Host "Deleting OneDrive cache..." -ForegroundColor Green
Remove-Item (Join-Path $env:LOCALAPPDATA 'Microsoft\OneDrive\settings') -Recurse -Force -ErrorAction SilentlyContinue

# Close edge
Write-Host "Closing Edge..." -ForegroundColor Green
'msedge','msedgewebview2' |
    ForEach-Object {
        Get-Process -Name $_ -ErrorAction SilentlyContinue |
            Stop-Process -Force -ErrorAction SilentlyContinue
    }

# Saving Edge data
Write-Host ""
Write-Host "Please export Bookmarks and Saved Passwords in Edge" -ForegroundColor Magenta
Write-Host "Bookmarks - > edge://favorites/" -ForegroundColor Magenta
Write-Host "Passwords - > edge://settings/autofill/passwords" -ForegroundColor Magenta
Write-Host "Opening Edge..." -ForegroundColor Magenta
Start-sleep -seconds 3
Start-Process "msedge.exe"
Write-Host "When done, press <Enter> for next step..." -ForegroundColor Yellow -nonewline
Read-Host

# Close edge
Write-Host "Closing Edge..." -ForegroundColor Green
'msedge','msedgewebview2' |
    ForEach-Object {
        Get-Process -Name $_ -ErrorAction SilentlyContinue |
            Stop-Process -Force -ErrorAction SilentlyContinue
    }

# Delete edge user profile
Write-Host "Deleting Edge user profile..." -ForegroundColor Green
$edgeUserData = Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\User Data'
Get-ChildItem $edgeUserData -Recurse -Force | Remove-ToRecycleBin -ErrorAction SilentlyContinue

# Wipe Office / AAD / WAM token + licensing caches (user-profile)
Write-Host "Wiping Office / AAD / WAM token + licensing caches..." -ForegroundColor Green
$paths = @(
    (Join-Path $env:LOCALAPPDATA 'Microsoft\Office\16.0\Licensing'),   # M365 Apps licensing tokens
    (Join-Path $env:LOCALAPPDATA 'Microsoft\Office\16.0\Wef'),
    (Join-Path $env:LOCALAPPDATA 'Microsoft\IdentityCache'),           # WAM tokens
    (Join-Path $env:LOCALAPPDATA 'Microsoft\TokenBroker'),
    (Join-Path $env:LOCALAPPDATA 'Microsoft\OneAuth'),                 # newer token store
    (Join-Path $env:LOCALAPPDATA 'Microsoft\Teams')                    # classic Teams cache
)

foreach ($path in $paths) {
    Write-Host "Wiping $path..."
    Remove-Item $path -Recurse -Force -ErrorAction SilentlyContinue
}

# Remove Office/AAD identity data from HKCU
Write-Host "Removing Office/AAD identity data from HKCU" -ForegroundColor Green
$regKeys = @(
    'HKCU:\Software\Microsoft\Office\16.0\Common\Identity',
    'HKCU:\Software\Microsoft\Office\16.0\Common\SignIn',
    'HKCU:\Software\Microsoft\IdentityCRL',
    'HKCU:\Software\Microsoft\AADBrokerPlugin'
)

foreach ($k in $regKeys) {
    Write-Host "Removing $k" -ForegroundColor Green
    Remove-Item $k -Recurse -Force -ErrorAction SilentlyContinue
}

# Purge all Microsoft / AAD / Office / OneDrive-related stored credentials
$regex = 'Microsoft_OC|MicrosoftOffice|MSOffice|OneDrive|MicrosoftAccount|virtualapp/didlogical|Microsoft_AAD|AzureAD|aad:|ADAL:'

$targets = cmdkey /list |
    Select-String 'Target:' |
    ForEach-Object { ($_ -replace '.*Target:\s*','').Trim() } |
    Where-Object { $_ -match $regex } |
    Sort-Object -Unique

foreach ($t in $targets) {
    Write-Host "Deleting credential: $t"
    cmdkey /delete:$t | Out-Null
}

$vb = Join-Path $PSScriptRoot 'OLicenseCleanup.vbs'
Invoke-Elevated {
    Write-Host "Now running elevated as: $env:USERNAME"

    & .\OLicenseCleanup.vbs

    dsregcmd /leave

    Write-Host "Leaving elevated prompt..." -ForegroundColor Green
    start-sleep -seconds 3
}

#reboot
Write-Host ""
Write-Host "It's now time to reboot the computer. Reboot? (Y/N):" -ForegroundColor Yellow -nonewline
$answer = Read-Host

if ($answer -notin @('Y','y','Yes','yes')) {
    Write-Host "Aborting reboot..." -ForegroundColor Yellow
    Write-Host ""
    exit
}

Restart-Computer -Force